
Plugin Management
*****************

.. todo:: Intro to the RADICAL PluginManager

PluginManager -- :mod:`radical.utils.plugin_manager`
----------------------------------------------------

.. automodule:: radical.utils.plugin_manager
   :show-inheritance:
   :members: PluginManager

