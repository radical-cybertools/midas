
__author__    = "Andre Merzky"
__copyright__ = "Copyright 2012-2013, The SAGA Project"
__license__   = "MIT"


from saga.adaptors.cpi.resource.manager   import Manager
from saga.adaptors.cpi.resource.resource  import Resource
from saga.adaptors.cpi.resource.resource  import Compute
from saga.adaptors.cpi.resource.resource  import Storage
from saga.adaptors.cpi.resource.resource  import Network




