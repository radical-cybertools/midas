
__author__    = "Andre Merzky"
__copyright__ = "Copyright 2012-2015, The SAGA Project"
__license__   = "MIT"


# ------------------------------------------------------------------------------
#
# saga.messages attribute and metric names:
# 
# attributes:
ID                = 'ID'
SENDER            = 'Sender'
STATE             = 'State'
TOPOLOGY          = 'Topology'
RELIABILITY       = 'Reliability'
ATOMICITY         = 'Atomicity'
ORDERING          = 'Ordering'
CORRECTNESS       = 'Correctness'

# metrics:
CONNECT           = 'Connect'
CLOSE             = 'Close'
MESSAGE           = 'Message'


# ------------------------------------------------------------------------------
#
# saga.messages enums:
# 
# common enums:
ANY               = 0

# state
OPEN              = 1
CLOSED            = 2

# topology
POINT_TO_POINT    = 1
MULTICAST         = 3
PUBLISH_SUBSCRIBE = 2
PEER_TO_PEER      = 4

# reliability
UNRELIABLE        = 1
CONSISTENT        = 3
SEMI_RELIABLE     = 2
RELIABLE          = 4

# atomicity
AT_MOST_ONCE      = 1
AT_LEAST_ONCE     = 2
EXACTLY_ONCE      = 3

# correctness
UNVERIFIED        = 1
VERIFIED          = 2

# ordering
UNORDERED         = 1
ORDERED           = 2
GLOBALLY_ORDERED  = 3


# ------------------------------------------------------------------------------

