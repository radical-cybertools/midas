
import pytest
import saga

# ------------------------------------------------------------------------------
#
@pytest.fixture (scope="module")
def job_service (session, cfg, request) :

    assert ('job_service_url' in cfg)

    js = saga.job.Service (cfg['job_service_url'], session=session)

    def close () :
        print ("close job service")
        js.close ()

    request.addfinalizer (close)

    return js


# ------------------------------------------------------------------------------

